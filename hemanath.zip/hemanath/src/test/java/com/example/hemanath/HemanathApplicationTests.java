package com.example.hemanath;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class HemanathApplicationTests {

    @Test
    void contextLoads() {
    }

}
