package com.example.hemanath.controllers;

import com.example.hemanath.apis.ServerApi;
import com.example.hemanath.entities.Server;
import com.example.hemanath.services.ServerService;
import lombok.NonNull;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController
public class ServerController implements ServerApi {

    private final ServerService serverService;

    public ServerController(ServerService serverService) {
        this.serverService = serverService;
    }

    @Override
    public Server saveServer(@NonNull Server server) {
        return serverService.saveServer(server);
    }

    @Override
    public List<Server> getAllServers() {
        return serverService.getAllServers();
    }

    @Override
    public Server getServerById(String serverId) {
        return serverService.getServerById(serverId);
    }

    @Override
    public Server getServerByName(String serverName) {
        return serverService.getServerByName(serverName);
    }

    @Override
    public void deleteServerById(String serverId) {
        serverService.deleteServerById(serverId);
    }
}
