package com.example.hemanath.entities;


import lombok.AllArgsConstructor;
import lombok.Data;
import org.springframework.data.annotation.Id;

@AllArgsConstructor
@Data
public class Server {
    @Id
    private String id;
    private String name;
    private String language;
    private String framework;
}
