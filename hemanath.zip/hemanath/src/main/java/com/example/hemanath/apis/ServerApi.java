package com.example.hemanath.apis;

import com.example.hemanath.entities.Server;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
public interface ServerApi {

    @PutMapping("/")
    Server saveServer(@RequestBody Server server);

    @GetMapping("/")
    List<Server> getAllServers();

    @GetMapping("/id")
    Server getServerById(@RequestParam("serverId") String serverId);

    @GetMapping("/name")
    Server getServerByName(@RequestParam("serverName") String serverName);

    @DeleteMapping("/")
    void deleteServerById(@RequestParam("serverId") String serverId);
}
