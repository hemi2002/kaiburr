package com.example.hemanath.exceptions;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.servlet.mvc.method.annotation.ResponseEntityExceptionHandler;

@ControllerAdvice
public class CustomExceptionHandler extends ResponseEntityExceptionHandler{

    @ExceptionHandler(ApiException.class)
    public ResponseEntity<ErrorObject> apiExceptionHandler(ApiException e){
        ErrorObject errorObject = new ErrorObject(e.getErrorCode(), e.getErrorMessage(), e.getStatus());

        return new ResponseEntity<>(errorObject, e.getStatus());
    }

}
