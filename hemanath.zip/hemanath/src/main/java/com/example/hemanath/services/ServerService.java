package com.example.hemanath.services;

import com.example.hemanath.entities.Server;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public interface ServerService {

    Server saveServer(Server server);

    List<Server> getAllServers();

    Server getServerById(String serverId);

    Server getServerByName(String serverName);

    void deleteServerById(String serverId);
}
