package com.example.hemanath.services;

import com.example.hemanath.constants.ErrorConstants;
import com.example.hemanath.entities.Server;
import com.example.hemanath.repositories.ServerRepository;
import com.example.hemanath.exceptions.ApiException;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class ServerServiceImpl implements ServerService{

    private final ServerRepository serverRepo;

    public ServerServiceImpl(ServerRepository serverRepo) {
        this.serverRepo = serverRepo;
    }

    @Override
    public Server saveServer(Server server) {

        if(!validateServer(server)){
            throw new ApiException(ErrorConstants.INVALID_SERVER.getErrorCode(), ErrorConstants.INVALID_SERVER.getErrorMessage(), HttpStatus.BAD_REQUEST);
        }

        return serverRepo.save(server);
    }

    @Override
    public List<Server> getAllServers() {
        return serverRepo.findAll();
    }

    @Override
    public Server getServerById(String serverId) {
        Optional<Server> serverOptional = serverRepo.findById(serverId);

        if(serverOptional.isEmpty()){
            throw new ApiException(ErrorConstants.SERVER_ID_NOT_PRESENT.getErrorCode(), ErrorConstants.SERVER_ID_NOT_PRESENT.getErrorMessage(), HttpStatus.NOT_FOUND);
        }

        return serverOptional.get();
    }

    @Override
    public Server getServerByName(String serverName) {
        Optional<Server> serverOptional = serverRepo.findByName(serverName);

        if(serverOptional.isEmpty()){
            throw new ApiException(ErrorConstants.SERVER_NAME_NOT_PRESENT.getErrorCode(), ErrorConstants.SERVER_NAME_NOT_PRESENT.getErrorMessage(), HttpStatus.NOT_FOUND);
        }

        return serverOptional.get();
    }

    @Override
    public void deleteServerById(String serverId) {
        if(!serverRepo.existsById(serverId)){
            throw new ApiException(ErrorConstants.SERVER_ID_NOT_PRESENT.getErrorCode(), ErrorConstants.SERVER_ID_NOT_PRESENT.getErrorMessage(), HttpStatus.NOT_FOUND);
        }

        serverRepo.deleteById(serverId);
    }

    private boolean validateServer(Server server){
        return !server.getId().isEmpty() && !server.getName().isEmpty() && !server.getLanguage().isEmpty() && !server.getFramework().isEmpty();
    }
}
