package com.example.hemanath.constants;

import lombok.Getter;

@Getter
public enum ErrorConstants {
    INVALID_SERVER("INVALID_SERVER", "The given server is invalid. Check if all the inputs are given and neither of them is empty"),
    SERVER_ID_NOT_PRESENT("SERVER_ID_NOT_PRESENT","The given server id is not present in the database"),
    SERVER_NAME_NOT_PRESENT("SERVER_NAME_NOT_PRESENT","The given server name is not present in the database");
    private final String errorCode;
    private final String errorMessage;

    ErrorConstants(String errorCode, String errorMessage) {
        this.errorCode = errorCode;
        this.errorMessage = errorMessage;
    }
}
