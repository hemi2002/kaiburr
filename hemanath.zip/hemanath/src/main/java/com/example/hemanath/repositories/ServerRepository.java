package com.example.hemanath.repositories;

import com.example.hemanath.entities.Server;
import org.springframework.data.mongodb.repository.MongoRepository;

import java.util.Optional;

public interface ServerRepository extends MongoRepository<Server, String> {

    Optional<Server> findByName(String serverName);
}
