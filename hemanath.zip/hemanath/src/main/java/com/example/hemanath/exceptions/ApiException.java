package com.example.hemanath.exceptions;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;
import org.springframework.http.HttpStatus;

@EqualsAndHashCode(callSuper = true)
@Data
@NoArgsConstructor
public class ApiException extends RuntimeException {

    private String errorCode;
    private String errorMessage;
    private HttpStatus status;

    public ApiException(String errorCode, String errorMessage, HttpStatus status) {
        super();
        this.errorCode = errorCode;
        this.errorMessage = errorMessage;
        this.status = status;
    }
}
