package com.example.hemanath;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class HemanathApplication {

    public static void main(String[] args) {
        SpringApplication.run(HemanathApplication.class, args);
    }

}
